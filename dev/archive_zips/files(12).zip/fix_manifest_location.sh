#!/usr/bin/env bash
# Quick fix for tw.py manifest location issue

set -e

echo "==================================================================="
echo "tw.py Manifest Location Fix"
echo "==================================================================="
echo ""

# Check if old manifest exists
if [[ -f ~/.task/.tw_manifest ]]; then
    echo "✓ Found manifest in OLD location: ~/.task/.tw_manifest"
    echo ""
    echo "Moving to correct location: ~/.task/config/.tw_manifest"
    
    # Create config directory if needed
    mkdir -p ~/.task/config
    
    # Move the file
    mv ~/.task/.tw_manifest ~/.task/config/.tw_manifest
    
    echo "✓ Manifest moved successfully!"
    echo ""
    echo "Contents:"
    cat ~/.task/config/.tw_manifest
    echo ""
elif [[ -f ~/.task/config/.tw_manifest ]]; then
    echo "✓ Manifest already in correct location"
    echo ""
    echo "Contents:"
    cat ~/.task/config/.tw_manifest
    echo ""
else
    echo "⚠️  No manifest found in either location!"
    echo ""
    echo "This means your installations weren't tracked."
    echo "You have two options:"
    echo ""
    echo "Option 1: Recreate manifest based on installed files"
    echo "  Run: ./recreate_manifest.sh"
    echo ""
    echo "Option 2: Reinstall apps (recommended)"
    echo "  Run: tw --install tw-recurrence"
    echo "  Run: tw --install need-priority"
    echo ""
    exit 1
fi

echo "==================================================================="
echo "Testing tw --list..."
echo "==================================================================="
tw --list
echo ""
echo "✅ Fix complete! tw --list should now show your installed apps."
echo "==================================================================="
