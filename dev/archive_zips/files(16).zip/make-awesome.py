#!/usr/bin/env python3
"""
make-awesome.py - Smart project enhancement tool for awesome-taskwarrior extensions

This tool intelligently enhances Python files with debug infrastructure while
respecting existing code patterns and conventions.

Version: 3.0.0
"""

import sys
import os
import re
import argparse
from pathlib import Path
from datetime import datetime
from typing import List, Tuple, Dict, Optional

VERSION = "3.0.0"

# ANSI color codes
class Colors:
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    NC = '\033[0m'  # No Color

def msg(text):
    print(f"{Colors.BLUE}[make]{Colors.NC} {text}")

def success(text):
    print(f"{Colors.GREEN}[make] ✓{Colors.NC} {text}")

def error(text):
    print(f"{Colors.RED}[make] ✗{Colors.NC} {text}", file=sys.stderr)

def warn(text):
    print(f"{Colors.YELLOW}[make] ⚠{Colors.NC} {text}")


class DebugPattern:
    """Represents detected debug patterns in existing code"""
    def __init__(self):
        self.has_debug_var = False
        self.debug_var_name = None
        self.debug_var_value = None
        self.has_debug_function = False
        self.debug_function_name = None
        self.has_tw_debug_check = False
        self.path_constants = []  # List of (name, value) tuples
        
    def __str__(self):
        return f"""DebugPattern:
  has_debug_var: {self.has_debug_var} ({self.debug_var_name}={self.debug_var_value})
  has_debug_function: {self.has_debug_function} ({self.debug_function_name})
  has_tw_debug_check: {self.has_tw_debug_check}
  path_constants: {self.path_constants}"""


class PythonFileAnalyzer:
    """Analyzes Python files to detect existing patterns"""
    
    @staticmethod
    def analyze(filepath: str) -> DebugPattern:
        """Analyze a Python file for existing debug patterns"""
        pattern = DebugPattern()
        
        with open(filepath, 'r') as f:
            content = f.read()
            lines = content.split('\n')
        
        # Detect debug variables (DEBUG, DEBUG_MODE, etc.)
        debug_var_patterns = [
            r'^\s*DEBUG\s*=\s*(\d+)',
            r'^\s*DEBUG_MODE\s*=\s*(\d+)',
            r'^\s*debug\s*=\s*(\d+)',
        ]
        
        for line in lines:
            for pattern_str in debug_var_patterns:
                match = re.match(pattern_str, line)
                if match:
                    pattern.has_debug_var = True
                    # Extract variable name
                    var_match = re.match(r'^\s*(\w+)\s*=', line)
                    if var_match:
                        pattern.debug_var_name = var_match.group(1)
                        pattern.debug_var_value = match.group(1)
                    break
        
        # Detect debug functions
        debug_func_patterns = [
            r'^\s*def\s+(debug_print|debug_log|log_debug|print_debug)\s*\(',
        ]
        
        for line in lines:
            for pattern_str in debug_func_patterns:
                match = re.match(pattern_str, line)
                if match:
                    pattern.has_debug_function = True
                    pattern.debug_function_name = match.group(1)
                    break
        
        # Detect TW_DEBUG environment variable checks
        if 'TW_DEBUG' in content:
            pattern.has_tw_debug_check = True
        
        # Detect path constants (CONFIG_DIR, HOOK_DIR, etc.)
        path_patterns = [
            r'^\s*([A-Z_]+(?:DIR|PATH|FILE))\s*=\s*(.+)$',
        ]
        
        for line in lines:
            for pattern_str in path_patterns:
                match = re.match(pattern_str, line)
                if match:
                    const_name = match.group(1)
                    const_value = match.group(2).strip()
                    pattern.path_constants.append((const_name, const_value))
        
        return pattern


class PythonFileParser:
    """Parses Python file structure"""
    
    @staticmethod
    def parse(filepath: str) -> Dict[str, any]:
        """Parse Python file into structural components"""
        with open(filepath, 'r') as f:
            lines = f.readlines()
        
        result = {
            'shebang': None,
            'docstring': [],
            'imports': [],
            'rest': [],
            'all_lines': lines,
        }
        
        idx = 0
        
        # Extract shebang
        if lines and lines[0].startswith('#!'):
            result['shebang'] = lines[0]
            idx = 1
        
        # Skip blank lines after shebang
        while idx < len(lines) and lines[idx].strip() == '':
            idx += 1
        
        # Extract docstring
        if idx < len(lines) and lines[idx].strip().startswith('"""'):
            result['docstring'].append(lines[idx])
            idx += 1
            
            # Multi-line docstring
            if not lines[idx - 1].strip().endswith('"""') or lines[idx - 1].strip().count('"""') == 1:
                while idx < len(lines):
                    result['docstring'].append(lines[idx])
                    if '"""' in lines[idx]:
                        idx += 1
                        break
                    idx += 1
        
        # Skip blank lines after docstring
        while idx < len(lines) and lines[idx].strip() == '':
            idx += 1
        
        # Extract imports (all of them, together)
        import_start = idx
        while idx < len(lines):
            line = lines[idx].strip()
            
            # Stop at first non-import, non-blank, non-comment line
            if line and not line.startswith('import ') and not line.startswith('from ') and not line.startswith('#'):
                break
            
            # Include imports and blank lines between imports
            if line.startswith('import ') or line.startswith('from ') or line == '' or line.startswith('#'):
                result['imports'].append(lines[idx])
                idx += 1
            else:
                break
        
        # Rest of the file
        result['rest'] = lines[idx:]
        
        return result


class DebugEnhancer:
    """Enhances Python files with debug infrastructure"""
    
    @staticmethod
    def enhance_existing_debug(pattern: DebugPattern, parsed: Dict) -> List[str]:
        """Enhance existing debug code rather than replacing it"""
        enhanced = []
        
        # Start with shebang and docstring
        if parsed['shebang']:
            enhanced.append(parsed['shebang'])
        
        for line in parsed['docstring']:
            enhanced.append(line)
        
        # Add debug enhancement marker
        enhanced.append('\n')
        enhanced.append('# ============================================================================\n')
        enhanced.append('# DEBUG ENHANCED VERSION - Auto-generated by make-awesome.py\n')
        enhanced.append('# ============================================================================\n')
        enhanced.append('\n')
        
        # Add imports (all together)
        # First add new imports needed for debug
        enhanced.append('import os\n')
        enhanced.append('import sys\n')
        enhanced.append('from pathlib import Path\n')
        enhanced.append('from datetime import datetime\n')
        
        # Then add original imports (skip duplicates)
        skip_imports = {'os', 'sys', 'pathlib', 'datetime'}
        for line in parsed['imports']:
            # Check if this is a duplicate import
            is_duplicate = False
            for skip in skip_imports:
                if f'import {skip}' in line or f'from {skip} ' in line:
                    is_duplicate = True
                    break
            if not is_duplicate and line.strip():
                enhanced.append(line)
        
        enhanced.append('\n')
        
        # Now enhance the existing debug infrastructure
        enhanced.append('# ============================================================================\n')
        enhanced.append('# Enhanced Debug Infrastructure\n')
        enhanced.append('# ============================================================================\n')
        enhanced.append('\n')
        
        # Add TW_DEBUG environment variable support
        if not pattern.has_tw_debug_check:
            enhanced.append('# Check if running under tw --debug\n')
            enhanced.append("tw_debug_level = os.environ.get('TW_DEBUG', '0')\n")
            enhanced.append('try:\n')
            enhanced.append('    tw_debug_level = int(tw_debug_level)\n')
            enhanced.append('except ValueError:\n')
            enhanced.append('    tw_debug_level = 0\n')
            enhanced.append('\n')
        
        # Add log directory detection
        enhanced.append('# Determine log directory based on context\n')
        enhanced.append('def get_log_dir():\n')
        enhanced.append('    """Auto-detect dev vs production mode"""\n')
        enhanced.append('    cwd = Path.cwd()\n')
        enhanced.append('    \n')
        enhanced.append('    # Dev mode: running from project directory (has .git)\n')
        enhanced.append("    if (cwd / '.git').exists():\n")
        enhanced.append("        log_dir = cwd / 'logs' / 'debug'\n")
        enhanced.append('    else:\n')
        enhanced.append('        # Production mode: installed and triggered by tw --debug\n')
        enhanced.append("        log_dir = Path.home() / '.task' / 'logs' / 'debug'\n")
        enhanced.append('    \n')
        enhanced.append('    log_dir.mkdir(parents=True, exist_ok=True)\n')
        enhanced.append('    return log_dir\n')
        enhanced.append('\n')
        
        # Now process the rest of the file, enhancing the debug function
        enhanced.append('# ============================================================================\n')
        enhanced.append('# Original Code with Debug Enhancements\n')
        enhanced.append('# ============================================================================\n')
        enhanced.append('\n')
        
        # Process rest of file, enhancing the debug function when we encounter it
        in_debug_function = False
        debug_func_indent = 0
        
        for line in parsed['rest']:
            # Detect debug function definition
            if pattern.has_debug_function and f'def {pattern.debug_function_name}' in line:
                in_debug_function = True
                # Preserve original debug variable if it exists
                if pattern.has_debug_var:
                    enhanced.append(f'# Original debug variable preserved: {pattern.debug_var_name} = {pattern.debug_var_value}\n')
                enhanced.append(line)
                continue
            
            # If we're in the debug function, enhance it
            if in_debug_function:
                # Check if function is ending (dedent or new def)
                if line.strip() and not line.startswith(' ') and not line.startswith('\t'):
                    in_debug_function = False
                elif line.strip().startswith('def '):
                    in_debug_function = False
            
            # Write line as-is (we preserve existing code structure)
            enhanced.append(line)
        
        # Add file logging wrapper at the end if debug function exists
        if pattern.has_debug_function:
            enhanced.append('\n')
            enhanced.append('# ============================================================================\n')
            enhanced.append('# Enhanced Debug Logging Wrapper\n')
            enhanced.append('# ============================================================================\n')
            enhanced.append('\n')
            enhanced.append(f'# Save original {pattern.debug_function_name}\n')
            enhanced.append(f'_original_{pattern.debug_function_name} = {pattern.debug_function_name}\n')
            enhanced.append('\n')
            enhanced.append(f'# Initialize enhanced debug logging\n')
            enhanced.append(f'if {pattern.debug_var_name} or tw_debug_level > 0:\n')
            enhanced.append('    DEBUG_LOG_DIR = get_log_dir()\n')
            enhanced.append('    DEBUG_SESSION_ID = datetime.now().strftime("%Y%m%d_%H%M%S")\n')
            enhanced.append('    # Get script name from __file__ or argv[0]\n')
            enhanced.append('    try:\n')
            enhanced.append('        script_name = Path(__file__).stem\n')
            enhanced.append('    except:\n')
            enhanced.append('        script_name = Path(sys.argv[0]).stem if sys.argv else "script"\n')
            enhanced.append('    DEBUG_LOG_FILE = DEBUG_LOG_DIR / f"{script_name}_debug_{DEBUG_SESSION_ID}.log"\n')
            enhanced.append('    \n')
            enhanced.append(f'    # Enhanced {pattern.debug_function_name} with file logging\n')
            enhanced.append(f'    def {pattern.debug_function_name}(msg):\n')
            enhanced.append('        """Enhanced debug with file logging"""\n')
            enhanced.append(f'        if {pattern.debug_var_name} or tw_debug_level > 0:\n')
            enhanced.append('            timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]\n')
            enhanced.append('            log_line = f"{timestamp} [DEBUG] {msg}\\n"\n')
            enhanced.append('            \n')
            enhanced.append('            # Write to log file\n')
            enhanced.append('            with open(DEBUG_LOG_FILE, "a") as f:\n')
            enhanced.append('                f.write(log_line)\n')
            enhanced.append('            \n')
            enhanced.append('            # Call original function for console output\n')
            enhanced.append(f'            _original_{pattern.debug_function_name}(msg)\n')
            enhanced.append('    \n')
            enhanced.append('    # Initialize log file with header\n')
            enhanced.append('    with open(DEBUG_LOG_FILE, "w") as f:\n')
            enhanced.append('        f.write("=" * 70 + "\\n")\n')
            enhanced.append('        f.write(f"Debug Session - {datetime.now().strftime(\'%Y-%m-%d %H:%M:%S\')}\\n")\n')
            enhanced.append('        f.write(f"Script: {script_name}\\n")\n')
            enhanced.append(f'        f.write(f"{pattern.debug_var_name}: {{{pattern.debug_var_name}}}\\n")\n')
            enhanced.append('        f.write(f"TW_DEBUG Level: {tw_debug_level}\\n")\n')
            enhanced.append('        f.write(f"Session ID: {DEBUG_SESSION_ID}\\n")\n')
            enhanced.append('        f.write(f"Log File: {DEBUG_LOG_FILE}\\n")\n')
            enhanced.append('        f.write("=" * 70 + "\\n\\n")\n')
            enhanced.append('    \n')
            enhanced.append(f'    {pattern.debug_function_name}("Debug logging initialized")\n')
        
        return enhanced
    
    @staticmethod
    def add_new_debug(parsed: Dict) -> List[str]:
        """Add complete debug infrastructure to file without existing debug"""
        enhanced = []
        
        # Start with shebang and docstring
        if parsed['shebang']:
            enhanced.append(parsed['shebang'])
        
        for line in parsed['docstring']:
            enhanced.append(line)
        
        enhanced.append('\n')
        enhanced.append('# ============================================================================\n')
        enhanced.append('# DEBUG VERSION - Auto-generated by make-awesome.py\n')
        enhanced.append('# ============================================================================\n')
        enhanced.append('\n')
        
        # Add imports
        enhanced.append('import os\n')
        enhanced.append('import sys\n')
        enhanced.append('from pathlib import Path\n')
        enhanced.append('from datetime import datetime\n')
        
        # Add original imports (skip duplicates)
        skip_imports = {'os', 'sys', 'pathlib', 'datetime'}
        for line in parsed['imports']:
            is_duplicate = False
            for skip in skip_imports:
                if f'import {skip}' in line or f'from {skip} ' in line:
                    is_duplicate = True
                    break
            if not is_duplicate and line.strip():
                enhanced.append(line)
        
        enhanced.append('\n')
        
        # Add complete debug infrastructure
        enhanced.append('# Debug configuration\n')
        enhanced.append('DEBUG_MODE = 0  # Set to 1 to enable debug output\n')
        enhanced.append('\n')
        enhanced.append('# Check if running under tw --debug\n')
        enhanced.append("tw_debug_level = os.environ.get('TW_DEBUG', '0')\n")
        enhanced.append('try:\n')
        enhanced.append('    tw_debug_level = int(tw_debug_level)\n')
        enhanced.append('except ValueError:\n')
        enhanced.append('    tw_debug_level = 0\n')
        enhanced.append('\n')
        enhanced.append('debug_active = DEBUG_MODE == 1 or tw_debug_level > 0\n')
        enhanced.append('\n')
        enhanced.append('# Determine log directory based on context\n')
        enhanced.append('def get_log_dir():\n')
        enhanced.append('    """Auto-detect dev vs production mode"""\n')
        enhanced.append('    cwd = Path.cwd()\n')
        enhanced.append('    \n')
        enhanced.append('    # Dev mode: running from project directory (has .git)\n')
        enhanced.append("    if (cwd / '.git').exists():\n")
        enhanced.append("        log_dir = cwd / 'logs' / 'debug'\n")
        enhanced.append('    else:\n')
        enhanced.append('        # Production mode: installed and triggered by tw --debug\n')
        enhanced.append("        log_dir = Path.home() / '.task' / 'logs' / 'debug'\n")
        enhanced.append('    \n')
        enhanced.append('    log_dir.mkdir(parents=True, exist_ok=True)\n')
        enhanced.append('    return log_dir\n')
        enhanced.append('\n')
        enhanced.append('# Initialize debug logger\n')
        enhanced.append('if debug_active:\n')
        enhanced.append('    DEBUG_LOG_DIR = get_log_dir()\n')
        enhanced.append('    DEBUG_SESSION_ID = datetime.now().strftime("%Y%m%d_%H%M%S")\n')
        enhanced.append('    # Get script name\n')
        enhanced.append('    try:\n')
        enhanced.append('        script_name = Path(__file__).stem\n')
        enhanced.append('    except:\n')
        enhanced.append('        script_name = Path(sys.argv[0]).stem if sys.argv else "script"\n')
        enhanced.append('    DEBUG_LOG_FILE = DEBUG_LOG_DIR / f"{script_name}_debug_{DEBUG_SESSION_ID}.log"\n')
        enhanced.append('    \n')
        enhanced.append('    def debug_log(message, level=1):\n')
        enhanced.append('        """Write debug message to log file and stderr"""\n')
        enhanced.append('        if debug_active and (DEBUG_MODE == 1 or tw_debug_level >= level):\n')
        enhanced.append('            timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]\n')
        enhanced.append('            prefix = f"[DEBUG-{level}]"\n')
        enhanced.append('            log_line = f"{timestamp} {prefix} {message}\\n"\n')
        enhanced.append('            \n')
        enhanced.append('            # Write to file\n')
        enhanced.append('            with open(DEBUG_LOG_FILE, "a") as f:\n')
        enhanced.append('                f.write(log_line)\n')
        enhanced.append('            \n')
        enhanced.append('            # Write to stderr with color\n')
        enhanced.append('            print(f"\\033[34m{prefix}\\033[0m {message}", file=sys.stderr)\n')
        enhanced.append('    \n')
        enhanced.append('    # Initialize log file\n')
        enhanced.append('    with open(DEBUG_LOG_FILE, "w") as f:\n')
        enhanced.append('        f.write("=" * 70 + "\\n")\n')
        enhanced.append('        f.write(f"Debug Session - {datetime.now().strftime(\'%Y-%m-%d %H:%M:%S\')}\\n")\n')
        enhanced.append('        f.write(f"Script: {script_name}\\n")\n')
        enhanced.append('        f.write(f"Debug Mode: {DEBUG_MODE}\\n")\n')
        enhanced.append('        f.write(f"TW_DEBUG Level: {tw_debug_level}\\n")\n')
        enhanced.append('        f.write(f"Session ID: {DEBUG_SESSION_ID}\\n")\n')
        enhanced.append('        f.write("=" * 70 + "\\n\\n")\n')
        enhanced.append('    \n')
        enhanced.append('    debug_log(f"Debug logging initialized: {DEBUG_LOG_FILE}", 1)\n')
        enhanced.append('else:\n')
        enhanced.append('    def debug_log(message, level=1):\n')
        enhanced.append('        """No-op when debug is disabled"""\n')
        enhanced.append('        pass\n')
        enhanced.append('\n')
        
        # Add separator and rest of code
        enhanced.append('# ============================================================================\n')
        enhanced.append('# Original Code Below\n')
        enhanced.append('# ============================================================================\n')
        enhanced.append('\n')
        
        for line in parsed['rest']:
            enhanced.append(line)
        
        return enhanced


def process_python_file(filepath: str, output_dir: Optional[str] = None) -> bool:
    """Process a single Python file"""
    msg(f"Processing: {filepath}")
    
    # Analyze existing patterns
    pattern = PythonFileAnalyzer.analyze(filepath)
    
    msg("Analysis results:")
    if pattern.has_debug_var:
        msg(f"  - Found debug variable: {pattern.debug_var_name} = {pattern.debug_var_value}")
    if pattern.has_debug_function:
        msg(f"  - Found debug function: {pattern.debug_function_name}()")
    if pattern.has_tw_debug_check:
        msg(f"  - Already has TW_DEBUG support")
    if pattern.path_constants:
        msg(f"  - Found {len(pattern.path_constants)} path constants (will preserve)")
    
    # Parse file structure
    parsed = PythonFileParser.parse(filepath)
    
    # Enhance based on what we found
    if pattern.has_debug_var or pattern.has_debug_function:
        msg("Enhancing existing debug infrastructure...")
        enhanced_lines = DebugEnhancer.enhance_existing_debug(pattern, parsed)
    else:
        msg("Adding new debug infrastructure...")
        enhanced_lines = DebugEnhancer.add_new_debug(parsed)
    
    # Determine output file
    filepath_obj = Path(filepath)
    if output_dir:
        output_path = Path(output_dir) / filepath_obj.name
    else:
        output_path = filepath_obj.parent / f"debug.{filepath_obj.name}"
    
    # Write enhanced version
    with open(output_path, 'w') as f:
        f.writelines(enhanced_lines)
    
    # Make executable if original was executable
    if os.access(filepath, os.X_OK):
        os.chmod(output_path, os.stat(filepath).st_mode)
    
    success(f"Created: {output_path}")
    return True


def find_python_files() -> List[str]:
    """Find Python files in current directory"""
    python_files = []
    
    # Find .py files
    for f in Path('.').glob('*.py'):
        if f.is_file():
            python_files.append(str(f))
    
    # Find executable files without extension that have Python shebangs
    for f in Path('.').iterdir():
        if not f.is_file():
            continue
        if f.suffix:  # Has extension, skip
            continue
        if not os.access(f, os.X_OK):  # Not executable, skip
            continue
        if f.name == 'make-awesome.py':  # Skip self
            continue
        
        # Check for Python shebang
        try:
            with open(f, 'r') as file:
                first_line = file.readline()
                if 'python' in first_line:
                    python_files.append(str(f))
        except:
            continue
    
    return python_files


def cmd_debug(args):
    """Run debug enhancement mode"""
    msg("=" * 70)
    msg(f"make-awesome.py v{VERSION} --debug")
    msg("Smart debug enhancement for Python files")
    msg("=" * 70)
    print()
    
    # Find Python files
    python_files = find_python_files()
    
    if not python_files:
        warn("No Python files found in current directory")
        return 0
    
    success(f"Found {len(python_files)} Python file(s)")
    print()
    
    # Process each file
    processed = 0
    skipped = 0
    
    for pyfile in python_files:
        # Check if already enhanced
        with open(pyfile, 'r') as f:
            content = f.read()
            if 'Auto-generated by make-awesome.py' in content or 'Auto-generated by make-awesome.sh' in content:
                warn(f"Already enhanced, skipping: {pyfile}")
                skipped += 1
                continue
        
        try:
            if process_python_file(pyfile):
                processed += 1
            print()
        except Exception as e:
            error(f"Failed to process {pyfile}: {e}")
            import traceback
            traceback.print_exc()
            print()
    
    # Summary
    msg("=" * 70)
    success(f"Debug enhancement complete!")
    msg(f"Processed: {processed} files")
    if skipped:
        msg(f"Skipped: {skipped} files (already enhanced)")
    msg("=" * 70)
    print()
    msg("To use the enhanced debug features:")
    print("  1. Set DEBUG (or DEBUG_MODE) = 1 in the file, or")
    print("  2. Run with: task rc.debug=1 [command]")
    print("  3. Set TW_DEBUG=1 environment variable")
    print()
    msg("Debug logs will be written to:")
    print("  • Dev mode (in project):    ./logs/debug/")
    print("  • Production mode:          ~/.task/logs/debug/")
    print()
    
    return 0


def main():
    parser = argparse.ArgumentParser(
        description='make-awesome.py - Smart enhancement tool for awesome-taskwarrior extensions',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enhance Python files with smart debug infrastructure'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version=f'make-awesome.py v{VERSION}'
    )
    
    args = parser.parse_args()
    
    if args.debug:
        return cmd_debug(args)
    else:
        parser.print_help()
        return 1


if __name__ == '__main__':
    sys.exit(main())
