# tw.py v2.0.0 - Quick Reference

## Installation

### One-Liner (Production Mode)
```bash
curl -fsSL https://raw.githubusercontent.com/linuxcaffe/awesome-taskwarrior/main/tw.py -o ~/.local/bin/tw && chmod +x ~/.local/bin/tw
```

### Add to PATH
```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

## Commands

| Command | Description | Example |
|---------|-------------|---------|
| `tw --available` | Browse all apps from GitHub | `tw --available` |
| `tw --install APP` | Install an app | `tw --install tw-recurrence` |
| `tw --remove APP` | Remove an app | `tw --remove tw-recurrence` |
| `tw --update APP` | Update (reinstall) an app | `tw --update tw-recurrence` |
| `tw --list` | List installed apps | `tw --list` |
| `tw --info APP` | Show app details | `tw --info tw-recurrence` |
| `tw --verify APP` | Verify checksums | `tw --verify tw-recurrence` |
| `tw --dry-run --install APP` | Preview installation | `tw --dry-run --install tw-recurrence` |
| `tw --version` | Show tw.py version | `tw --version` |
| `tw --help` | Show help | `tw --help` |
| `tw <task-args>` | Pass to taskwarrior | `tw add "Buy milk" due:tomorrow` |

## Mode Detection

**Production Mode** (no repo clone):
```bash
~/.local/bin/tw --available
# Output: "Running in PRODUCTION mode (fetching from GitHub)"
```

**Dev Mode** (in repo):
```bash
cd ~/awesome-taskwarrior
./tw.py --available
# Output: "Running in DEV mode (using local files)"
```

## Common Workflows

### Install Your First App
```bash
tw --available              # Browse apps
tw --install tw-recurrence  # Install one
tw --list                   # Verify
tw --info tw-recurrence     # See details
```

### Update an App
```bash
tw --update tw-recurrence   # Remove + reinstall
```

### Verify Installation
```bash
tw --verify tw-recurrence   # Check checksums
tw --info tw-recurrence     # See installed files
```

### Clean Up
```bash
tw --remove tw-recurrence   # Remove app
```

## File Locations

| Type | Location | Description |
|------|----------|-------------|
| tw.py | `~/.local/bin/tw` | Package manager |
| Manifest | `~/.task/.tw_manifest` | Install tracking |
| Hooks | `~/.task/hooks/` | Hook scripts |
| Scripts | `~/.task/scripts/` | Helper tools |
| Config | `~/.task/config/` | Config files |
| Docs | `~/.task/docs/` | READMEs |

## Manifest Format

```
app-name|version|/path/to/file|checksum|date
```

Example:
```
tw-recurrence|0.3.7|/home/user/.task/hooks/on-add_recurrence.py||2026-01-23T12:00:00Z
tw-recurrence|0.3.7|/home/user/.task/hooks/on-exit_recurrence.py||2026-01-23T12:00:00Z
```

## GitHub Integration

**Registry API:**
```
https://api.github.com/repos/linuxcaffe/awesome-taskwarrior/contents/registry.d
```

**Raw File URLs:**
```
https://raw.githubusercontent.com/linuxcaffe/awesome-taskwarrior/main/registry.d/app-name.meta
https://raw.githubusercontent.com/linuxcaffe/awesome-taskwarrior/main/installers/app-name.install
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "command not found: tw" | Add `~/.local/bin` to PATH |
| "Running in DEV mode" unexpectedly | Remove local registry.d/ or move tw.py |
| "Failed to fetch from GitHub" | Check internet, verify repo exists |
| "Installer not found" | Check .meta filename matches installer |
| App won't install | Check --available shows it |

## Environment Variables

Installers receive these from tw.py:

```bash
INSTALL_DIR=$HOME/.task
HOOKS_DIR=$HOME/.task/hooks
SCRIPTS_DIR=$HOME/.task/scripts
CONFIG_DIR=$HOME/.task/config
DOCS_DIR=$HOME/.task/docs
LOGS_DIR=$HOME/.task/logs
TASKRC=$HOME/.taskrc
TW_COMMON=/path/to/tw-common.sh  # (if dev mode)
TW_DRY_RUN=1                     # (if --dry-run)
```

## For Developers

### Test Both Modes
```bash
# Production mode
cp tw.py /tmp/tw && cd /tmp && ./tw --available

# Dev mode
cd ~/awesome-taskwarrior && ./tw.py --available
```

### Create New App
1. Create `installers/my-app.install`
2. Create `registry.d/my-app.meta`
3. Test: `./tw.py --install my-app`
4. Push to GitHub
5. Users can: `tw --install my-app`

### Meta File Template
```ini
name=My App Name
version=1.0.0
type=hook
description=Brief description
repo=https://github.com/user/repo
base_url=https://raw.githubusercontent.com/user/repo/main/
files=hook.py:hook,config.rc:config,README.md:doc
checksums=hash1,hash2,hash3
author=Your Name
license=MIT
requires_taskwarrior=2.6.0
requires_python=3.6
```

### Installer Template
```bash
#!/usr/bin/env bash
set -euo pipefail

APPNAME="my-app"
VERSION="1.0.0"

# Detect environment
: "${HOOKS_DIR:=$HOME/.task/hooks}"
: "${CONFIG_DIR:=$HOME/.task/config}"

# Optional tw-common.sh
if [[ -f "${TW_COMMON:-}" ]]; then
    source "$TW_COMMON"
fi

install() {
    # Download files, install them
    # Use tw_manifest_add if available
}

remove() {
    # Remove files
    # Use tw_uninstall_app if available
}

case "${1:-}" in
    install) install ;;
    remove) remove ;;
    *) echo "Usage: $0 {install|remove}" ;;
esac
```

## Version History

- **v2.0.0**: GitHub integration, hybrid mode, --available command
- **v1.x**: Local repo only, no GitHub fetching

## Links

- **Repo**: https://github.com/linuxcaffe/awesome-taskwarrior
- **Issues**: https://github.com/linuxcaffe/awesome-taskwarrior/issues
- **Wiki**: https://github.com/linuxcaffe/awesome-taskwarrior/wiki
- **Taskwarrior**: https://taskwarrior.org

## Quick Examples

```bash
# Install tw.py
curl -fsSL https://raw.githubusercontent.com/linuxcaffe/awesome-taskwarrior/main/tw.py -o ~/.local/bin/tw && chmod +x ~/.local/bin/tw

# Browse apps
tw --available

# Install app
tw --install tw-recurrence

# Use normally
tw add "Test task" r:1d due:tomorrow ty:p

# Check status
tw --list
tw --info tw-recurrence

# Update
tw --update tw-recurrence

# Remove
tw --remove tw-recurrence
```

## Key Features

✅ No repo clone needed  
✅ Fetches from GitHub  
✅ Auto-detects mode  
✅ Manifest tracking  
✅ Checksum verification  
✅ Pass-through to task  
✅ Dry-run support  
✅ Browse before install  

## Need Help?

```bash
tw --help           # Show help
tw --version        # Show version
tw --available      # Browse apps
tw --info APP       # Show app details
```

For bugs: https://github.com/linuxcaffe/awesome-taskwarrior/issues
