# tw.py v2.0.0 - Changes from Original

## Architecture Comparison

### OLD: Local Repo Required
```
User must clone repo:
~/awesome-taskwarrior/
├── tw.py
├── registry.d/
│   └── *.meta
├── installers/
│   └── *.install
└── lib/
    └── tw-common.sh

tw.py reads from local directories only
```

### NEW: Hybrid Mode
```
PRODUCTION MODE (no repo needed):
~/.local/bin/tw  (standalone file)
    ↓
Fetches from GitHub:
- registry.d/*.meta (via GitHub API)
- installers/*.install (via raw URLs)
    ↓
Installs to ~/.task/
Tracks in ~/.task/.tw_manifest

DEV MODE (in repo):
~/awesome-taskwarrior/
├── tw.py  (detects local dirs)
├── registry.d/  (uses these)
└── installers/  (uses these)
```

## Code Changes

### 1. PathManager - Mode Detection

**OLD:**
```python
def __init__(self):
    self.tw_root = Path(__file__).parent.absolute()
    self.registry_dir = self.tw_root / "registry.d"
    self.installers_dir = self.tw_root / "installers"
    # Always expects these to exist locally
```

**NEW:**
```python
def __init__(self):
    self.tw_root = Path(__file__).parent.absolute()
    self.local_registry = self.tw_root / "registry.d"
    self.local_installers = self.tw_root / "installers"
    
    # Auto-detect mode
    self.is_dev_mode = (
        self.local_registry.exists() and 
        self.local_installers.exists()
    )
    
    if self.is_dev_mode:
        print("[tw] Running in DEV mode (using local files)")
    else:
        print("[tw] Running in PRODUCTION mode (fetching from GitHub)")
```

### 2. New RegistryManager Class

**OLD:** None - Always read local files

**NEW:**
```python
class RegistryManager:
    """Manages app registry - local or remote"""
    
    def get_available_apps(self):
        if self.is_dev_mode:
            return self._get_local_apps()
        else:
            return self._get_remote_apps()  # GitHub API
    
    def get_meta(self, app_name):
        if self.is_dev_mode:
            return self._get_local_meta(app_name)
        else:
            return self._get_remote_meta(app_name)  # GitHub raw URL
    
    def get_installer_path(self, app_name):
        if self.is_dev_mode:
            return str(self.paths.local_installers / f"{app_name}.install")
        else:
            return self._download_installer(app_name)  # GitHub raw URL
```

### 3. GitHub Integration

**NEW:** Added GitHub API calls
```python
GITHUB_REPO = "linuxcaffe/awesome-taskwarrior"
GITHUB_BRANCH = "main"
GITHUB_API_BASE = f"https://api.github.com/repos/{GITHUB_REPO}"
GITHUB_RAW_BASE = f"https://raw.githubusercontent.com/{GITHUB_REPO}/{GITHUB_BRANCH}"

def _get_remote_apps(self):
    """Fetch available apps from GitHub API"""
    url = f"{GITHUB_API_BASE}/contents/registry.d"
    req = Request(url)
    req.add_header('Accept', 'application/vnd.github.v3+json')
    response = urlopen(req)
    files = json.loads(response.read().decode('utf-8'))
    # Parse and return app names

def _download_installer(self, app_name):
    """Download installer from GitHub to temp file"""
    url = f"{GITHUB_RAW_BASE}/installers/{app_name}.install"
    response = urlopen(url)
    content = response.read().decode('utf-8')
    
    # Save to temp file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.install', delete=False) as f:
        f.write(content)
        return f.name
```

### 4. MetaFile Class Enhancement

**OLD:** Takes file path
```python
class MetaFile:
    def __init__(self, meta_path):
        self.meta_path = Path(meta_path)
        self._parse()
    
    def _parse(self):
        with open(self.meta_path, 'r') as f:
            # parse file
```

**NEW:** Takes content string (works with files or URLs)
```python
class MetaFile:
    def __init__(self, content):
        """Initialize with content string (from file or URL)"""
        self._parse(content)
    
    def _parse(self, content):
        """Parse the .meta file content"""
        for line in content.split('\n'):
            # parse content string
```

### 5. AppManager - Temp File Cleanup

**NEW:** Cleans up downloaded installers
```python
def install(self, app_name, dry_run=False):
    installer_path = self.registry.get_installer_path(app_name)
    
    try:
        result = subprocess.run([installer_path, 'install'], env=env)
        
        # NEW: Clean up temp file if in production mode
        if not self.paths.is_dev_mode:
            os.unlink(installer_path)
        
        return result.returncode == 0
    
    except Exception as e:
        # NEW: Always clean up on error
        if not self.paths.is_dev_mode:
            try:
                os.unlink(installer_path)
            except:
                pass
```

### 6. New --available Command

**OLD:** No command to browse available apps

**NEW:**
```python
def list_available(self):
    """List all available applications"""
    apps = self.registry.get_available_apps()
    
    for app_name in apps:
        meta = self.registry.get_meta(app_name)
        installed = "✓ INSTALLED" if self.manifest.is_installed(app_name) else ""
        print(f"{app_name:<35} v{version:<10} {installed}")
        print(f"    {desc}")
```

### 7. Enhanced show_info

**NEW:** Shows additional metadata fields
```python
def show_info(self, app_name):
    # Show additional metadata if present
    for key in ['author', 'license', 'requires_taskwarrior', 'requires_python']:
        value = meta.get(key)
        if value:
            print(f"{key.replace('_', ' ').title()}: {value}")
```

## User Experience Changes

### Installation Workflow

**OLD:**
```bash
# Must clone repo
git clone https://github.com/linuxcaffe/awesome-taskwarrior.git
cd awesome-taskwarrior
./tw.py --install tw-recurrence
```

**NEW - Production:**
```bash
# No repo clone needed!
curl -fsSL https://raw.githubusercontent.com/.../tw.py -o ~/.local/bin/tw
chmod +x ~/.local/bin/tw
tw --install tw-recurrence
```

**NEW - Dev:**
```bash
# Clone for development
git clone https://github.com/linuxcaffe/awesome-taskwarrior.git
cd awesome-taskwarrior
./tw.py --install tw-recurrence  # Uses local files
```

### Browsing Apps

**OLD:**
```bash
# No built-in way, had to:
ls registry.d/
cat registry.d/app-name.meta
```

**NEW:**
```bash
# Built-in command
tw --available
# Shows all apps with descriptions and install status
```

### User Feedback

**OLD:**
```
[tw] Installing app-name...
[tw] ✓ Successfully installed app-name
```

**NEW:**
```
[tw] Running in PRODUCTION mode (fetching from GitHub)
[tw] Downloading installer from GitHub...
[tw] Installing app-name...
[tw] ✓ Successfully installed app-name
```

## Benefits

### For End Users
1. **No repo clone needed** - Just one file to download
2. **Always up-to-date** - Fetches latest from GitHub
3. **Browse apps** - `--available` shows what's installable
4. **Cleaner system** - No large repo, just ~/.local/bin/tw
5. **Same commands** - No workflow changes

### For Developers
1. **Local testing** - Dev mode uses local files
2. **Fast iteration** - No push/pull for testing
3. **Production testing** - Can test GitHub mode too
4. **Clear separation** - Dev vs prod behavior obvious
5. **Debug friendly** - Mode printed on startup

### For Package Manager
1. **True package manager** - Like pip, npm, apt
2. **No git dependency** - Pure Python + curl
3. **Scalable** - GitHub API handles load
4. **Version agnostic** - Works with any GitHub branch
5. **Fork friendly** - Easy to point to different repo

## Migration Path

### Existing Users (have repo cloned)
```bash
# Option 1: Keep using dev mode
cd ~/awesome-taskwarrior
./tw.py --install app-name  # Still works!

# Option 2: Switch to production mode
cp tw.py ~/.local/bin/tw
tw --install app-name  # Uses GitHub now
```

### New Users
```bash
# Just install tw.py standalone
curl -fsSL ... -o ~/.local/bin/tw
chmod +x ~/.local/bin/tw
tw --available
tw --install app-name
```

## Testing Both Modes

```bash
# Test production mode
cp ~/awesome-taskwarrior/tw.py /tmp/tw-test
cd /tmp
./tw-test --available
# Output: "Running in PRODUCTION mode (fetching from GitHub)"

# Test dev mode
cd ~/awesome-taskwarrior
./tw.py --available
# Output: "Running in DEV mode (using local files)"
```

## Key Implementation Details

1. **Mode detection is automatic** - No config needed
2. **GitHub API for listing** - Gets file list
3. **Raw URLs for content** - Gets actual files
4. **Temp files for installers** - Auto-cleanup
5. **MetaFile takes string** - Works with files or URLs
6. **RegistryManager abstracts source** - Clean separation
7. **Error handling enhanced** - Better messages
8. **Pass-through preserved** - Still works as task wrapper

## What Didn't Change

1. **Manifest format** - Same ~/.task/.tw_manifest
2. **Installer API** - Same environment variables
3. **CLI commands** - All original flags work
4. **Directory structure** - Same ~/.task/ layout
5. **File types** - Same hook/script/config/doc
6. **Checksum verification** - Same algorithm
7. **Pass-through** - Same task wrapper behavior

## Summary

The new tw.py is **backwards compatible** while adding **GitHub integration** and **standalone operation**. Users can choose between:

- **Production mode**: One file, fetches from GitHub, always current
- **Dev mode**: Full repo, local files, fast testing

Both modes use the same manifest system and installer API, ensuring consistency.
