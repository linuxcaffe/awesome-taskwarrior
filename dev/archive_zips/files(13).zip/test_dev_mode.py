#!/usr/bin/env python3
"""
Test script to demonstrate dev mode indicator behavior
"""

from pathlib import Path

# Simulate dev mode
class MockPaths:
    def __init__(self, is_dev):
        self.is_dev_mode = is_dev
        if is_dev:
            self.local_registry = Path("/home/djp/awesome-taskwarrior/registry.d")
        else:
            self.local_registry = None

def show_dev_mode_if_needed(paths):
    """Show dev mode indicator for package management commands"""
    if paths.is_dev_mode:
        print(f"[tw] DEV MODE - using local registry: {paths.local_registry}")

# Test in DEV mode
print("=== TESTING IN DEV MODE ===\n")
paths_dev = MockPaths(True)

print("Example: tw --list")
show_dev_mode_if_needed(paths_dev)
print("[tw] Installed applications:")
print("[tw]   tw-recurrence (v1.0.0)")
print()

print("Example: tw --install tw-need-priority")
show_dev_mode_if_needed(paths_dev)
print("[tw] Installing tw-need-priority...")
print("[tw] [+] Installed: tw-need-priority")
print()

print("Example: tw --info tw-recurrence")
show_dev_mode_if_needed(paths_dev)
print("[tw] Application: tw-recurrence")
print("[tw]   Name: Taskwarrior Enhanced Recurrence")
print("[tw]   Version: 1.0.0")
print()

# Test in PRODUCTION mode
print("\n=== TESTING IN PRODUCTION MODE ===\n")
paths_prod = MockPaths(False)

print("Example: tw --list")
show_dev_mode_if_needed(paths_prod)
print("[tw] Installed applications:")
print("[tw]   tw-recurrence (v1.0.0)")
print()

print("Example: tw --install tw-need-priority")
show_dev_mode_if_needed(paths_prod)
print("[tw] Installing tw-need-priority...")
print("[tw] [+] Installed: tw-need-priority")
print()

print("\n=== SUMMARY ===")
print("✓ Dev mode shows clear indicator with local registry path")
print("✓ Production mode shows no indicator (clean output)")
print("✓ Indicator only appears for package management commands")
print("✓ Pass-through to task shows no indicator")
