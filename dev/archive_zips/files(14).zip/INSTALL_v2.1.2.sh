#!/bin/bash
#
# Install updated tw.py v2.1.2 with dev mode indicator
#
# This script will backup your current tw.py and install the updated version
#

set -e

PROJECT_DIR="$HOME/dev/awesome-taskwarrior"
BACKUP_DIR="$PROJECT_DIR/dev/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo "[install] Installing tw.py v2.1.2 with dev mode indicator"
echo

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

# Backup current tw.py
if [ -f "$PROJECT_DIR/tw.py" ]; then
    echo "[install] Backing up current tw.py to $BACKUP_DIR/tw.py.$TIMESTAMP"
    cp "$PROJECT_DIR/tw.py" "$BACKUP_DIR/tw.py.$TIMESTAMP"
fi

# Copy updated tw.py (you'll need to download this first)
# For now, show the manual steps:

echo "[install] To complete installation:"
echo
echo "1. Download tw.py from Claude's outputs"
echo "2. Copy it to: $PROJECT_DIR/tw.py"
echo "3. Make it executable: chmod +x $PROJECT_DIR/tw.py"
echo
echo "Then test with:"
echo "  cd $PROJECT_DIR"
echo "  ./tw.py --list"
echo
echo "You should see:"
echo "  [tw] DEV MODE - using local registry: $PROJECT_DIR/registry.d"
echo "  [tw] Installed applications:"
echo "  ..."
