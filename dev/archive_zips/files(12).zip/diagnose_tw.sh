#!/usr/bin/env bash
# Diagnostic script to check manifest and installation status

echo "==================================================================="
echo "awesome-taskwarrior Installation Diagnostic"
echo "==================================================================="
echo ""

echo "Checking tw installation..."
which tw
echo "tw location: $(which tw)"
echo ""

echo "Checking tw version..."
tw --version 2>&1 || echo "ERROR: tw --version failed"
echo ""

echo "Checking for manifest files..."
echo ""

# Check old location
if [[ -f ~/.task/.tw_manifest ]]; then
    echo "⚠️  OLD LOCATION FOUND: ~/.task/.tw_manifest"
    echo "   This should be moved to ~/.task/config/.tw_manifest"
    echo "   File contents:"
    cat ~/.task/.tw_manifest
    echo ""
fi

# Check new location
if [[ -f ~/.task/config/.tw_manifest ]]; then
    echo "✓ CORRECT LOCATION: ~/.task/config/.tw_manifest"
    echo "   File contents:"
    cat ~/.task/config/.tw_manifest
    echo ""
else
    echo "✗ NOT FOUND: ~/.task/config/.tw_manifest"
    echo ""
fi

# Check for installed files
echo "Checking for installed hook files..."
if [[ -d ~/.task/hooks ]]; then
    hooks=$(ls ~/.task/hooks/*.py 2>/dev/null | wc -l)
    echo "Found $hooks Python hooks in ~/.task/hooks/"
    ls -la ~/.task/hooks/*.py 2>/dev/null || echo "  No hooks found"
else
    echo "✗ ~/.task/hooks/ does not exist"
fi
echo ""

echo "Checking for installed config files..."
if [[ -d ~/.task/config ]]; then
    configs=$(ls ~/.task/config/*.rc 2>/dev/null | wc -l)
    echo "Found $configs .rc files in ~/.task/config/"
    ls -la ~/.task/config/*.rc 2>/dev/null || echo "  No config files found"
else
    echo "✗ ~/.task/config/ does not exist"
fi
echo ""

echo "Checking for installed scripts..."
if [[ -d ~/.task/scripts ]]; then
    scripts=$(ls ~/.task/scripts/ 2>/dev/null | grep -v "^tw$" | wc -l)
    echo "Found $scripts scripts in ~/.task/scripts/ (excluding tw itself)"
    ls -la ~/.task/scripts/ 2>/dev/null | grep -v "^tw$" || echo "  No scripts found"
else
    echo "✗ ~/.task/scripts/ does not exist"
fi
echo ""

echo "==================================================================="
echo "RECOMMENDATIONS:"
echo "==================================================================="

if [[ -f ~/.task/.tw_manifest ]] && [[ ! -f ~/.task/config/.tw_manifest ]]; then
    echo "1. Move manifest to correct location:"
    echo "   mv ~/.task/.tw_manifest ~/.task/config/.tw_manifest"
    echo ""
fi

if [[ ! -f ~/.task/config/.tw_manifest ]]; then
    echo "2. Manifest is missing! You need to either:"
    echo "   a) Reinstall apps with: tw --install tw-recurrence need-priority"
    echo "   b) Manually create ~/.task/config/.tw_manifest with your install data"
    echo ""
fi

# Check tw.py version
if command -v tw &> /dev/null; then
    tw_version=$(grep "VERSION = " $(which tw) 2>/dev/null | cut -d'"' -f2)
    if [[ "$tw_version" == "2.1.1" ]]; then
        echo "✓ tw.py version is correct: $tw_version"
    else
        echo "⚠️  tw.py version: $tw_version (expected 2.1.1)"
        echo "   You may need to update tw with the fixed version"
    fi
else
    echo "✗ tw command not found in PATH"
fi

echo ""
echo "==================================================================="
