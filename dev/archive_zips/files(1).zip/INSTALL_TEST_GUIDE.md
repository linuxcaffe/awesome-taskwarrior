# tw.py v2.0.0 - GitHub-Enabled Installation & Testing Guide

## Overview

This version of tw.py supports **hybrid operation**:
- **DEV MODE**: When run from awesome-taskwarrior repo (uses local registry.d/ and installers/)
- **PRODUCTION MODE**: When run standalone (fetches registry and installers from GitHub)

## Quick Installation (Production Mode)

### One-Command Install
```bash
curl -fsSL https://raw.githubusercontent.com/linuxcaffe/awesome-taskwarrior/main/tw.py -o ~/.local/bin/tw && chmod +x ~/.local/bin/tw
```

### Manual Install
```bash
# Create bin directory if needed
mkdir -p ~/.local/bin

# Download tw.py
curl -fsSL https://raw.githubusercontent.com/linuxcaffe/awesome-taskwarrior/main/tw.py -o ~/.local/bin/tw

# Make executable
chmod +x ~/.local/bin/tw

# Add to PATH if not already (add to ~/.bashrc or ~/.zshrc)
export PATH="$HOME/.local/bin:$PATH"

# Verify installation
tw --version
```

## Usage Examples

### List Available Apps (from GitHub)
```bash
tw --available
```

### Install an App
```bash
tw --install tw-recurrence
```

### List Installed Apps
```bash
tw --list
```

### Show App Info
```bash
tw --info tw-recurrence
```

### Update an App
```bash
tw --update tw-recurrence
```

### Remove an App
```bash
tw --remove tw-recurrence
```

### Verify Checksums
```bash
tw --verify tw-recurrence
```

### Dry Run
```bash
tw --dry-run --install tw-recurrence
```

### Pass-through to Taskwarrior
```bash
tw add "Buy milk" due:tomorrow
tw list
tw done 1
```

## Testing Workflow

### Test Production Mode (Standalone)

```bash
# 1. Install tw.py standalone
curl -fsSL https://raw.githubusercontent.com/linuxcaffe/awesome-taskwarrior/main/tw.py -o /tmp/tw
chmod +x /tmp/tw

# 2. Test GitHub fetching
/tmp/tw --available
# Should show: "Running in PRODUCTION mode (fetching from GitHub)"
# Should list all available apps

# 3. Test installation from GitHub
/tmp/tw --install tw-recurrence
# Should download installer from GitHub and run it

# 4. Verify installation
/tmp/tw --list
# Should show tw-recurrence

# 5. Test info
/tmp/tw --info tw-recurrence
# Should show details

# 6. Test removal
/tmp/tw --remove tw-recurrence

# 7. Clean up
rm /tmp/tw
```

### Test Dev Mode (Local Repo)

```bash
# 1. Clone or navigate to awesome-taskwarrior repo
cd ~/awesome-taskwarrior

# 2. Run tw.py from repo
./tw.py --available
# Should show: "Running in DEV mode (using local files)"
# Should list apps from local registry.d/

# 3. Test local installation
./tw.py --install tw-recurrence
# Should use local installers/tw-recurrence.install

# 4. Test other commands
./tw.py --list
./tw.py --info tw-recurrence
./tw.py --remove tw-recurrence
```

## How It Works

### Production Mode Detection
```python
# tw.py checks if registry.d/ and installers/ exist in same directory
self.tw_root = Path(__file__).parent.absolute()
self.local_registry = self.tw_root / "registry.d"
self.local_installers = self.tw_root / "installers"
self.is_dev_mode = self.local_registry.exists() and self.local_installers.exists()
```

### GitHub Fetching
```python
# Uses GitHub API to list registry files
GITHUB_API_BASE = "https://api.github.com/repos/linuxcaffe/awesome-taskwarrior"

# Downloads raw files
GITHUB_RAW_BASE = "https://raw.githubusercontent.com/linuxcaffe/awesome-taskwarrior/main"
```

### Manifest Tracking
```bash
# Local manifest at ~/.task/.tw_manifest
# Format: app|version|filepath|checksum|date
tw-recurrence|0.3.7|/home/user/.task/hooks/on-add_recurrence.py||2026-01-23T12:00:00Z
tw-recurrence|0.3.7|/home/user/.task/hooks/on-exit_recurrence.py||2026-01-23T12:00:00Z
```

## Troubleshooting

### "Running in PRODUCTION mode" but I'm in the repo
- Make sure registry.d/ and installers/ directories exist
- Check you're running ./tw.py not tw from PATH

### "Failed to fetch registry from GitHub"
- Check internet connection
- Check GitHub is accessible
- Verify repo name: linuxcaffe/awesome-taskwarrior

### "Installer not found"
- In production mode: Check GitHub has the installer
- In dev mode: Check installers/app-name.install exists

### App shows in --available but won't install
- Check the .meta file has correct installer name
- Verify installer exists in GitHub or local installers/

## For Developers

### Creating New Apps

1. Create installer: `installers/my-app.install`
2. Create metadata: `registry.d/my-app.meta`
3. Test locally: `./tw.py --install my-app`
4. Commit and push to GitHub
5. Users can install: `tw --install my-app` (no repo clone needed!)

### Testing Changes

```bash
# Local testing
cd ~/awesome-taskwarrior
./tw.py --available  # Uses local files

# Production testing
cp tw.py /tmp/tw-test
cd /tmp
./tw-test --available  # Fetches from GitHub
```

## Key Features

✅ **No repo clone needed** - Users just need tw.py file  
✅ **Auto-detects mode** - Dev mode if in repo, production otherwise  
✅ **GitHub integration** - Fetches registry and installers on-demand  
✅ **Manifest tracking** - Clean uninstalls  
✅ **Pass-through** - Works as task wrapper  
✅ **--available command** - Browse apps without installing  
✅ **Checksums** - Optional verification  
✅ **Dry-run** - Preview actions  

## What's New in v2.0.0

1. **Hybrid Mode**: Auto-detects local repo vs standalone
2. **GitHub Fetching**: Downloads registry and installers from GitHub
3. **RegistryManager**: Abstracts local vs remote access
4. **--available**: New command to browse apps
5. **Better UX**: Clear mode indicators, formatted output
6. **Temp File Handling**: Auto-cleanup of downloaded installers
7. **Enhanced Error Handling**: Better error messages

## Migration from v1.x

Old way (required repo clone):
```bash
git clone https://github.com/linuxcaffe/awesome-taskwarrior.git
cd awesome-taskwarrior
./tw.py --install app-name
```

New way (standalone):
```bash
curl -fsSL https://raw.githubusercontent.com/linuxcaffe/awesome-taskwarrior/main/tw.py -o ~/.local/bin/tw
chmod +x ~/.local/bin/tw
tw --install app-name
```

Both ways still work! Use dev mode for development, production mode for users.
