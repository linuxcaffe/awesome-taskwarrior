#!/usr/bin/env bash
#
# verify-package.sh - Verify awesome-taskwarrior v2.0.0 package contents
#

set -euo pipefail

echo "=== Verifying awesome-taskwarrior v2.0.0 Package ==="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

pass=0
fail=0
warn=0

check_file() {
    local file="$1"
    local expected_lines="${2:-0}"
    
    if [[ ! -f "$file" ]]; then
        echo -e "${RED}✗${NC} Missing: $file"
        ((fail++))
        return 1
    fi
    
    local lines
    lines=$(wc -l < "$file")
    
    if [[ $expected_lines -gt 0 ]]; then
        if [[ $lines -ge $expected_lines ]]; then
            echo -e "${GREEN}✓${NC} Found: $file ($lines lines)"
            ((pass++))
        else
            echo -e "${YELLOW}⚠${NC} Found but short: $file ($lines lines, expected ~$expected_lines)"
            ((warn++))
        fi
    else
        echo -e "${GREEN}✓${NC} Found: $file ($lines lines)"
        ((pass++))
    fi
}

check_executable() {
    local file="$1"
    
    if [[ ! -x "$file" ]]; then
        echo -e "${YELLOW}⚠${NC} Not executable: $file"
        ((warn++))
        return 1
    fi
    
    echo -e "${GREEN}✓${NC} Executable: $file"
    ((pass++))
}

# Check if we're in the extracted directory
if [[ ! -f "tw.py" ]]; then
    echo -e "${RED}Error: Must be run from awesome-taskwarrior-v2.0.0 directory${NC}"
    echo "Usage: cd awesome-taskwarrior-v2.0.0 && bash verify-package.sh"
    exit 1
fi

echo "Checking core files..."
check_file "tw.py" 500
check_executable "tw.py"
check_file "lib/tw-common.sh" 500
check_executable "lib/tw-common.sh"

echo ""
echo "Checking documentation..."
check_file "dev/API.md" 500
check_file "DEVELOPERS.md" 250
check_file "CONTRIBUTING.md" 300
check_file "MIGRATION.md" 300

echo ""
echo "Checking templates..."
check_file "dev/models/hook-template.meta" 20
check_file "dev/models/hook-template.install" 200
check_executable "dev/models/hook-template.install"
check_file "dev/models/wrapper-template.meta" 20
check_file "dev/models/wrapper-template.install" 150
check_executable "dev/models/wrapper-template.install"

echo ""
echo "Checking example implementation..."
check_file "registry.d/tw-recurrence.meta" 15
check_file "installers/tw-recurrence.install" 200
check_executable "installers/tw-recurrence.install"

echo ""
echo "=== Verification Summary ==="
echo -e "${GREEN}Passed:${NC} $pass"
[[ $warn -gt 0 ]] && echo -e "${YELLOW}Warnings:${NC} $warn"
[[ $fail -gt 0 ]] && echo -e "${RED}Failed:${NC} $fail"

echo ""
if [[ $fail -eq 0 ]]; then
    echo -e "${GREEN}✓ Package verification complete!${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Review the files"
    echo "  2. Test standalone: bash installers/tw-recurrence.install install"
    echo "  3. Test with tw.py: ./tw.py --install tw-recurrence"
    echo "  4. Copy to repository: cp -r * ~/dev/awesome-taskwarrior/"
    exit 0
else
    echo -e "${RED}✗ Package verification failed${NC}"
    exit 1
fi
