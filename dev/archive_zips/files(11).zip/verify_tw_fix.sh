#!/usr/bin/env bash
# Quick verification that tw.py has been properly fixed
# Run this from the awesome-taskwarrior directory

set -e

echo "==================================================================="
echo "tw.py GitHub Integration Fix - Verification Script"
echo "==================================================================="
echo ""

# Check if we're in the right directory
if [[ ! -f "tw.py" ]]; then
    echo "ERROR: tw.py not found in current directory"
    echo "Please run this from the awesome-taskwarrior directory"
    exit 1
fi

# Check version
VERSION=$(grep "^VERSION = " tw.py | cut -d'"' -f2)
echo "✓ Found tw.py version: $VERSION"

if [[ "$VERSION" != "2.1.1" ]]; then
    echo "  ⚠ Warning: Version is $VERSION, expected 2.1.1"
fi

echo ""
echo "Checking for RegistryManager usage in AppManager methods..."
echo ""

# Check each method
methods=(
    "install.*self.registry.get_installer"
    "remove.*self.registry.get_installer"
    "list_installed.*self.registry.get_meta"
    "list_tags.*self.registry.list_apps"
    "show_info_all.*self.registry.list_apps"
    "def show_info.*self.registry.get_meta"
    "verify.*self.registry.get_meta"
)

all_good=true

for method_pattern in "${methods[@]}"; do
    method_name=$(echo "$method_pattern" | cut -d'.' -f1)
    pattern=$(echo "$method_pattern" | cut -d'*' -f2)
    
    if grep -q "$pattern" tw.py; then
        echo "✓ $method_name uses $pattern"
    else
        echo "✗ $method_name MISSING $pattern"
        all_good=false
    fi
done

echo ""
echo "Checking for temp file cleanup..."
if grep -q "is_temp_file and installer_path" tw.py; then
    echo "✓ Temp file cleanup code present"
else
    echo "✗ Temp file cleanup code MISSING"
    all_good=false
fi

echo ""
echo "Checking for old patterns that should be removed..."
old_patterns=(
    "self.paths.installers_dir / f\"{app_name}.install\""
    "self.paths.registry_dir.glob"
)

found_old=false
for pattern in "${old_patterns[@]}"; do
    # Escape the pattern for grep
    if grep -qF "$pattern" tw.py; then
        echo "⚠ Found old pattern: $pattern"
        found_old=true
    fi
done

if [[ "$found_old" == "false" ]]; then
    echo "✓ No old patterns found"
fi

echo ""
echo "==================================================================="
if [[ "$all_good" == "true" && "$found_old" == "false" ]]; then
    echo "✅ ALL CHECKS PASSED - tw.py is properly fixed!"
    echo ""
    echo "Next steps:"
    echo "  1. Test in production mode: Copy tw.py to ~/.task/scripts/tw"
    echo "  2. Test commands: tw --list, tw --info <app>, tw --install <app>"
    echo "  3. Test in dev mode: ./tw.py --list (from this directory)"
    echo "  4. Commit and push to GitHub"
else
    echo "❌ SOME CHECKS FAILED - Review the output above"
    exit 1
fi
echo "==================================================================="
