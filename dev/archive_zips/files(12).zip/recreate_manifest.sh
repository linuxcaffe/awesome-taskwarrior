#!/usr/bin/env bash
# Recreate .tw_manifest from currently installed files
# Use this if your manifest was lost but files are still installed

set -e

MANIFEST_FILE="$HOME/.task/config/.tw_manifest"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

echo "==================================================================="
echo "Recreating tw Manifest from Installed Files"
echo "==================================================================="
echo ""

# Create config directory if needed
mkdir -p ~/.task/config

# Backup existing manifest if present
if [[ -f "$MANIFEST_FILE" ]]; then
    backup="$MANIFEST_FILE.backup.$(date +%Y%m%d_%H%M%S)"
    echo "Backing up existing manifest to: $backup"
    cp "$MANIFEST_FILE" "$backup"
    echo ""
fi

# Clear manifest
> "$MANIFEST_FILE"

echo "Scanning for installed files..."
echo ""

# Function to add entry to manifest
add_to_manifest() {
    local app=$1
    local version=$2
    local filepath=$3
    echo "$app|$version|$filepath||$TIMESTAMP" >> "$MANIFEST_FILE"
    echo "  Added: $filepath"
}

# Scan for tw-recurrence files
if [[ -f ~/.task/hooks/on-add_recurrence.py ]]; then
    echo "Found tw-recurrence installation:"
    add_to_manifest "tw-recurrence" "2.0.0" "$HOME/.task/hooks/on-add_recurrence.py"
    add_to_manifest "tw-recurrence" "2.0.0" "$HOME/.task/hooks/on-exit_recurrence.py"
    [[ -f ~/.task/hooks/on-modify_recurrence.py ]] && \
        add_to_manifest "tw-recurrence" "2.0.0" "$HOME/.task/hooks/on-modify_recurrence.py"
    [[ -f ~/.task/config/recurrence.rc ]] && \
        add_to_manifest "tw-recurrence" "2.0.0" "$HOME/.task/config/recurrence.rc"
    [[ -f ~/.task/scripts/rr ]] && \
        add_to_manifest "tw-recurrence" "2.0.0" "$HOME/.task/scripts/rr"
    [[ -f ~/.task/docs/recurrence_README.md ]] && \
        add_to_manifest "tw-recurrence" "2.0.0" "$HOME/.task/docs/recurrence_README.md"
    echo ""
fi

# Scan for need-priority files  
if [[ -f ~/.task/hooks/on-add_priority.py ]]; then
    echo "Found need-priority installation:"
    add_to_manifest "need-priority" "0.3.3" "$HOME/.task/hooks/on-add_priority.py"
    [[ -f ~/.task/hooks/on-exit_priority.py ]] && \
        add_to_manifest "need-priority" "0.3.3" "$HOME/.task/hooks/on-exit_priority.py"
    [[ -f ~/.task/hooks/on-modify_priority.py ]] && \
        add_to_manifest "need-priority" "0.3.3" "$HOME/.task/hooks/on-modify_priority.py"
    [[ -f ~/.task/scripts/migrate_priority.py ]] && \
        add_to_manifest "need-priority" "0.3.3" "$HOME/.task/scripts/migrate_priority.py"
    [[ -f ~/.task/scripts/nn.py ]] && \
        add_to_manifest "need-priority" "0.3.3" "$HOME/.task/scripts/nn.py"
    [[ -f ~/.task/config/need.rc ]] && \
        add_to_manifest "need-priority" "0.3.3" "$HOME/.task/config/need.rc"
    [[ -f ~/.task/docs/need-priority_README.md ]] && \
        add_to_manifest "need-priority" "0.3.3" "$HOME/.task/docs/need-priority_README.md"
    echo ""
fi

if [[ ! -s "$MANIFEST_FILE" ]]; then
    echo "⚠️  No installed files found!"
    echo "Are you sure apps are installed?"
    exit 1
fi

echo "==================================================================="
echo "Manifest recreated at: $MANIFEST_FILE"
echo "==================================================================="
echo ""
cat "$MANIFEST_FILE"
echo ""
echo "==================================================================="
echo "Testing tw --list..."
echo "==================================================================="
tw --list
echo ""
echo "✅ Manifest recreated successfully!"
echo "==================================================================="
