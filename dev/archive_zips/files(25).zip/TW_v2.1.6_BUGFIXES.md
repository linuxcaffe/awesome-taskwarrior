# tw v2.1.6 - Critical Bugfixes

## Summary
Fixed two critical bugs from v2.1.5: -A flag not receiving its argument, and -p flag not preserving colors/layout.

---

## Bug #1: -A/--attach Not Receiving Task ID 🔴 FIXED

### Problem
```bash
$ tw -A 59
usage: tw [-I APP] [-r APP] [-u APP] [-l] [-i [APP]] [--verify APP] [--tags] [--dry-run] [--debug [LEVEL]] [-v] [-h] [-s] [-p] [-A TASKID]
tw: error: argument -A/--attach: expected one argument
```

The task ID `59` was being separated from the `-A` flag during argument processing.

### Root Cause
The argument splitting logic that prevents argparse from scanning all arguments was too aggressive. It would split:
- `['-A', '59']` into:
- `args_for_parser = ['-A']`
- `remaining_args = ['59']`

So argparse never saw the `59` argument!

### The Fix
Added special handling for flags that expect arguments:

```python
flags_with_args = ['-I', '-r', '-u', '-i', '-A', '--install', '--remove', 
                  '--update', '--info', '--attach', '--verify']

expect_flag_arg = False

for arg in sys.argv[1:]:
    if expect_flag_arg:
        # This is the argument for the previous flag
        args_for_parser.append(arg)
        expect_flag_arg = False
    elif arg.startswith('-'):
        args_for_parser.append(arg)
        flag_base = arg.split('=')[0]
        if flag_base in flags_with_args and '=' not in arg:
            expect_flag_arg = True  # Next arg belongs to this flag
```

### Now Works
```bash
# All these work now:
tw -A 59                  ✅ Task ID properly received
tw --attach 42            ✅ Works
tw -I app-name            ✅ Works
tw -r app-name            ✅ Works
tw -u app-name            ✅ Works

# Still properly pass through:
tw add test -A note       ✅ Goes to task command
```

### Debug Output
With `TW_DEBUG_WRAPPER=1`:
```bash
$ TW_DEBUG_WRAPPER=1 tw -A 59
[tw-debug] sys.argv = ['tw', '-A', '59']
[tw-debug] first_arg = '-A'
[tw-debug] is_valid = True, error_msg = None
[tw-debug] First arg is valid tw flag, processing with argparse
[tw-debug] args_for_parser = ['-A', '59']     ← BOTH included!
[tw-debug] remaining_args = []
[tw-debug] Parsed args: {'attach': '59', ...}
[tw] Attaching to task 59...
```

---

## Bug #2: -p/--pager Not Preserving Colors/Layout 🔴 FIXED

### Problem
Output from `tw -p list` was:
- Colors stripped
- Layout jumbled
- Text not properly formatted

### Root Cause
Three issues in the `run_with_pager()` function:

1. **Not forcing color**: Taskwarrior detects output is being captured (not a TTY) and disables colors
2. **No width setting**: Taskwarrior uses default width instead of terminal width
3. **Wrong less flag**: Used `-r` instead of `-R` for ANSI color codes

### The Fix

**1. Force color and set width:**
```python
# OLD - no color forcing
cmd = [task_bin] + task_args

# NEW - force color and width
cmd = [task_bin] + task_args + [
    f'rc._forcecolor=on',        # Force colors even in pipe
    f'rc.defaultwidth={cols}'    # Use terminal width
]
```

**2. Use proper less flag:**
```python
# OLD - basic raw mode
pager_cmd = [pager, '-r', '-X', '-F']

# NEW - ANSI color mode
pager_cmd = [pager, '-R', '-X', '-F']
```

### Now Works
```bash
# Beautiful colored output with proper layout:
tw -p list
tw --pager next +work
tw -p status:pending

# Scrollable with proper formatting:
# - Colors preserved
# - Columns aligned
# - Table borders visible
# - Search works (/ in less)
```

### Comparison

**Before (broken):**
```
ID Description Status
1 Task one Pending
2 Task two Pending
  [colors stripped, layout compressed]
```

**After (fixed):**
```
ID  Description                Status
---  ------------------------  ---------
  1  Task one                  Pending
  2  Task two                  Pending
[colors preserved, proper spacing, borders visible]
```

### Implementation Details

The fix mimics the `tless` bash function approach:
```bash
# Original tless function that inspired the fix:
tless() {
    echo "$("$@" rc._forcecolor=on rc.defaultwidth=`tput cols`)" | less -R -X -F
}
```

Now tw's `-p` flag does this internally!

---

## All Fixes in v2.1.6

### ✅ Fixed: Flag argument handling
- `-A 59` now works correctly
- All flags with arguments properly handled: `-I`, `-r`, `-u`, `-i`, `-A`
- Argument splitting logic improved

### ✅ Fixed: Pager color preservation
- Colors forced with `rc._forcecolor=on`
- Width set with `rc.defaultwidth={cols}`
- Less uses `-R` for ANSI colors

### ✅ Fixed: Pager layout
- Terminal width properly detected and used
- Table formatting preserved
- Column alignment maintained

---

## Testing

### Test -A flag
```bash
# Create a test task
tw add Test attachment feature
# Note the task ID (e.g., 60)

# Test attach
tw -A 60
# Should launch ranger without errors

# Test with label
tw -A 60
# Enter label: "Reference"
# Select a file
# Should add annotation successfully
```

### Test -p flag
```bash
# Test with short output (shouldn't page)
tw -p version

# Test with long output (should page with colors)
tw -p list

# Verify colors in pager:
# - Use / to search
# - Use n for next match  
# - Colors should be visible
# - Layout should be aligned
# - Press q to exit

# Test with different reports
tw -p next
tw -p status:pending list
tw -p all
```

### Test debug mode
```bash
# See the fix in action
TW_DEBUG_WRAPPER=1 tw -A 60
# Should show args_for_parser includes both '-A' and '60'

TW_DEBUG_WRAPPER=1 tw -p list
# Should show proper command execution
```

---

## Technical Details

### Flags Requiring Arguments
The following flags expect an argument and are now specially handled:

**Short flags:**
- `-I` (install)
- `-r` (remove)
- `-u` (update)
- `-i` (info - optional)
- `-A` (attach)

**Long flags:**
- `--install`
- `--remove`
- `--update`
- `--info` (optional)
- `--attach`
- `--verify`

### Pager Behavior

**Terminal Detection:**
```python
rows, cols = os.popen('stty size', 'r').read().split()
```

**Smart Paging:**
- Output < screen height: Print directly (no pager)
- Output >= screen height: Use pager
- No pager available: Print directly (graceful fallback)

**Less Flags:**
- `-R`: Interpret ANSI color codes
- `-X`: Don't clear screen on exit
- `-F`: Auto-exit if content fits on one screen

---

## Migration from v2.1.5

No breaking changes! Just bug fixes:

```bash
# Update
cp tw ~/.task/scripts/tw
chmod +x ~/.task/scripts/tw

# Verify
tw --version
# Should show: tw v2.1.6

# Test the fixes
tw -A <taskid>    # Should work now
tw -p list        # Should have colors now
```

---

## Known Remaining Issues

### Minor Issues
- Pager doesn't handle terminal resize during viewing
- No config option to set default pager behavior yet
- Less flags not user-configurable yet

### Future Enhancements (v2.1.7?)
- Config option for auto-paging
- Custom pager command
- Alternative pagers (most, bat, etc.)
- Pager flag customization

---

## Comparison: Before vs After

### -A Flag

| Scenario | v2.1.5 | v2.1.6 |
|----------|--------|--------|
| `tw -A 59` | ❌ Error | ✅ Works |
| `tw -I app` | ❌ Error | ✅ Works |
| `tw -r app` | ❌ Error | ✅ Works |

### -p Flag

| Aspect | v2.1.5 | v2.1.6 |
|--------|--------|--------|
| Colors | ❌ Stripped | ✅ Preserved |
| Layout | ❌ Jumbled | ✅ Proper |
| Width | ❌ Default | ✅ Terminal |
| Less flag | `-r` | `-R` |

---

**tw v2.1.6** - Both features now work correctly! 🎯
